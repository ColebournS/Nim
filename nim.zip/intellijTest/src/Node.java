public class Node {
    private String color;
    private boolean open;
    private int row;
    private int col;
    public Node(String c){
        color = c;
        open = true;

    }
    public void setColor(String c){
        color = c;
    }
    public String getColor(){ return color.substring(0,1); }
    public void setOpen(){
        open = true;
    }
    public void setClosed(){
        open = false;
        color = "X";
    }
    public boolean getOpen(){
        return open;
    }
}
