import java.util.Locale;
import java.util.Scanner;

//“Double Trouble” is really a particular instantiation of the fundamental com-binatorial game.
// What is the real name of the game: Nim
// who “solved” it, and when? the earliest European references to Nim are from the beginning of the 16th century. Its current name was coined by Charles L.Bouton of Harvard University,
// who also developed the complete theory of the game in 1901,[3] but the origins of the name were never fully explained.
// Where does it show up in popular culture? Nim Style games show up all over in miniture-game play.

public class Main {

    public static void main(String[] args) {
        playGame();
    }

    public static void playGame(){
        boolean first;
        boolean computerWin = true;
        Node[][] nodeList = new Node[5][5];
        boolean game = true;

        System.out.println("Starting Game...");
        for(int i=1; i<6 ; i++){
            for(int j =0; j<i; j++){
                nodeList[i-1][j] = makeNode(i);
            }
        }
        printBoard(nodeList);
        first = firstMove();
        if(first){
            while(game) {
                playerMove(nodeList);
                if(leftOfColor("green",nodeList)+leftOfColor("red",nodeList)+leftOfColor("yellow",nodeList) == 0){
                    computerWin = false;
                    game = false;
                    break;
                }
                computerMove(nodeList);
                if(leftOfColor("green",nodeList)+leftOfColor("red",nodeList)+leftOfColor("yellow",nodeList) == 0) {
                    game = false;
                }
            }
        }
        else{
            while(game) {
                computerMove(nodeList);
                if(leftOfColor("green",nodeList)+leftOfColor("red",nodeList)+leftOfColor("yellow",nodeList) == 0){
                    game = false;
                    break;
                }
                playerMove(nodeList);
                if(leftOfColor("green",nodeList)+leftOfColor("red",nodeList)+leftOfColor("yellow",nodeList) == 0) {
                    game = false;
                    computerWin = false;
                }
            }
        }
        if(computerWin) System.out.println("You lost to the computer");
        else System.out.println("You beat the computer!");
        System.out.println("Game Over...");
        boolean again = playAgain();
        if(again){
            playGame();
        }
    }

    public static boolean firstMove(){
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Would you like to go first?(Y/N)");
        String move = myObj.nextLine();  // Read user input
        if(move.equals("Y") || move.equals("y") || move.equals("Yes")|| move.equals("yes")|| move.equals("YES")){
            return true;
        }
        else if(move.equals("N") || move.equals("n") || move.equals("no")|| move.equals("No")|| move.equals("NO")){
            return false;
        }
        else{
            System.out.println("Error...Please enter Y or N");
            return firstMove();
        }
    }

    private static void printBoard(Node[][] list){
        for(int i=1; i< 6 ; i++){
            for(int j =0; j<i; j++){
                switch(list[i-1][j].getColor()){
                    case "g" -> System.out.print(ConsoleColors.GREEN_BACKGROUND + list[i-1][j].getColor().toUpperCase(Locale.ROOT) + "  " + ConsoleColors.RESET);
                    case "y" -> System.out.print(ConsoleColors.YELLOW_BACKGROUND + list[i-1][j].getColor().toUpperCase(Locale.ROOT) + "  " + ConsoleColors.RESET);
                    case "r" -> System.out.print(ConsoleColors.RED_BACKGROUND + list[i-1][j].getColor().toUpperCase(Locale.ROOT) + "  " + ConsoleColors.RESET);
                    case "X" -> System.out.print(ConsoleColors.BLACK_BACKGROUND + list[i-1][j].getColor().toUpperCase(Locale.ROOT) + "  " + ConsoleColors.RESET);
                }
            }
            System.out.print("\n");
        }
    }

    private static Node makeNode(int row) {
     if(row==1) return new Node("green");
     else if(row==2) return new Node("green");
     else if(row==3) return new Node("yellow");
     else if(row==4) return new Node("yellow");
     else return new Node("red");
    }

    public static void playerMove(Node[][] list){
        String colorsLeft = colorLeftString(list);
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.printf("What color do you choose? (%s) \n",colorsLeft);
        String colorChoose = myObj.nextLine();  // Read user input
        if(colorsLeft.contains(colorChoose.toUpperCase(Locale.ROOT))){
            switch (colorChoose) {
                case "G" -> colorRemover("green", list);
                case "Y" -> colorRemover("yellow", list);
                case "R" -> colorRemover("red", list);
                case "g" -> colorRemover("g", list);
                case "y" -> colorRemover("y", list);
                case "r" -> colorRemover("r", list);
                default -> {
                    System.out.printf("Error...Please enter %s\n",colorsLeft);
                    playerMove(list);
                }
            }
        }
        else{
            System.out.printf("Error...Please enter %s\n",colorsLeft);
            playerMove(list);
        }

        System.out.println("Player Turn Over...");
        printBoard(list);
    }

    public static void colorRemover(String c, Node[][] list){
        int num = leftOfColor(c,list);
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.printf("How many would you like to turn?(You can choose up to %d)\n",num);
        int numRemove = Integer.parseInt(myObj.nextLine());  // Read user input
        if(numRemove<=num && numRemove > 0) {
            for (int i = 0; i < 5; i++) {
                for (int j = 0; j <= i; j++) {
                    if (list[i][j].getColor().equals(c.substring(0, 1)) && list[i][j].getOpen()) {
                        if (numRemove > 0) {
                            numRemove--;
                            list[i][j].setClosed();
                        }
                    }
                }
            }
        }
        else{
            System.out.printf("Error...Please enter number less than or equal to %d \n",num);
            colorRemover(c,list);
        }
    }

    public static void ComputerColorRemover(String c, Node[][] list,int num){
        int numRemove = num;
            for (int i = 0; i < 5; i++) {
                for (int j = 0; j <= i; j++) {
                    if (list[i][j].getColor().equals(c.substring(0, 1)) && list[i][j].getOpen()) {
                        if (numRemove > 0) {
                            numRemove--;
                            list[i][j].setClosed();
                        }
                    }
                }
            }
    }

    public static int leftOfColor(String color,Node[][] list){
        int count = 0;
        for(int i=0; i< 5 ; i++){
            for(int j =0; j<=i; j++){
                if(list[i][j].getColor().equals(color.substring(0,1)) && list[i][j].getOpen()){
                    count++;
                }
            }
        }
        return count;
    }

    public static void computerMove(Node[][] list){
        System.out.println("Computer is choosing...");
        int x = currentNim(list);
        int gX = greenSum(list) ^ x;
        int yX = yellowSum(list) ^ x;
        int rX = redSum(list) ^ x;
        if (x != 0) {
            if (greenSum(list) > 0 && redSum(list) > 0 && redSum(list) > 0) {
                if (gX < greenSum(list)) {
                    ComputerColorRemover("green", list, (greenSum(list) - gX));
                } else if (rX < redSum(list)) {
                    ComputerColorRemover("red", list, (redSum(list) - rX));
                } else if (yX < yellowSum(list)) {
                    ComputerColorRemover("yellow", list, (yellowSum(list) - yX));
                }
            }
            else if (greenSum(list) == 0) {
                if (redSum(list) > yellowSum(list)) {
                    ComputerColorRemover("red", list, redSum(list) - yellowSum(list));
                } else ComputerColorRemover("yellow", list, yellowSum(list) - redSum(list));
            }
            else if (yellowSum(list) == 0) {
                if (redSum(list) > greenSum(list)) {
                    ComputerColorRemover("red", list, redSum(list) - yellowSum(list));
                } else ComputerColorRemover("green", list, greenSum(list) - redSum(list));
            }
            else if (redSum(list) == 0) {
                if (greenSum(list) > yellowSum(list)) {
                    ComputerColorRemover("green", list, greenSum(list) - yellowSum(list));
                } else ComputerColorRemover("yellow", list, yellowSum(list) - greenSum(list));
            }

        }
        else{
            if (redSum(list) >= greenSum(list) && redSum(list) >= yellowSum(list)) {
                ComputerColorRemover("red", list, 1);
            }
            else if (yellowSum(list) >= greenSum(list) && yellowSum(list) >= redSum(list)) {
                ComputerColorRemover("yellow", list, 1);
            }
            else{
                ComputerColorRemover("green", list, 1);
            }
        }
        System.out.println("Computer Turn Over...");
        printBoard(list);
    }

    private static int currentNim(Node[][] list) {
        int greenSum =0;
        int yellowSum = 0;
        int redSum = 0;
        for(int i=0; i< 2 ; i++){
            for(int j =0; j<=i; j++){
                if(list[i][j].getOpen()){
                    greenSum++;
                }
            }
        }
        for(int i=2; i< 4 ; i++){
            for(int j =0; j<=i; j++){
                if(list[i][j].getOpen()){
                    yellowSum++;
                }
            }
        }
        for(int i=4; i< 5 ; i++) {
            for (int j = 0; j <= i; j++) {
                if (list[i][j].getOpen()) {
                    redSum++;
                }
            }
        }
        return greenSum^yellowSum^redSum;
    }

    private static int greenSum(Node[][] list) {
        int greenSum =0;
        for(int i=0; i< 2 ; i++){
            for(int j =0; j<=i; j++){
                if(list[i][j].getOpen()){
                    greenSum++;
                }
            }
        }
        return greenSum;
    }

    private static int yellowSum(Node[][] list) {
        int yellowSum = 0;

        for(int i=2; i< 4 ; i++){
            for(int j =0; j<=i; j++){
                if(list[i][j].getOpen()){
                    yellowSum++;
                }
            }
        }
        return yellowSum;
    }

    private static int redSum(Node[][] list) {
        int redSum = 0;
        for(int i=4; i< 5 ; i++) {
            for (int j = 0; j <= i; j++) {
                if (list[i][j].getOpen()) {
                    redSum++;
                }
            }
        }
        return redSum;
    }

    public static boolean playAgain(){
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Would you like to play again?(Y/N)");
        String move = myObj.nextLine();  // Read user input
        if(move.equals("Y") || move.equals("y") || move.equals("Yes")|| move.equals("yes")|| move.equals("YES")){
            return true;
        }
        else if(move.equals("N") || move.equals("n") || move.equals("no")|| move.equals("No")|| move.equals("NO")){
            return false;
        }
        else{
            System.out.println("Error...Please enter Y or N");
            return playAgain();
        }
    }

    public static String colorLeftString(Node[][] list){
        String s="";
        if(greenSum(list) >0) s+= "G ";
        if(yellowSum(list) >0) s+= "Y ";
        if(redSum(list) >0) s+= "R";
        return s;
    }
}

